//
//  ViewController.swift
//  Test
//
//  Created by Ilhammalik on 27/05/20.
//  Copyright © 2020 Ilhammalik. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
